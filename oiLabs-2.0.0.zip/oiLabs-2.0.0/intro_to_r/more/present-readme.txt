

- present:

Description
Number of male and female births, sex ratio at birth, and number of excess males: United States, 1940–2002. (Mathews, TJ and Hamilton, B.E. Trend analysis of the sex ratio at birth in the United States. National Vital Statistics Reports. vol 53, no. 20, pp 1 - 17, 2005. http://www.cdc.gov/nchs/data/nvsr/nvsr53/nvsr53_20.pdf)

Format
A data frame with 63 observations on the following 3 variables.
	year: a numeric vector, 1940-2002
	boys: a numeric vector, number of male births
	girls: a numeric vector, number of female births